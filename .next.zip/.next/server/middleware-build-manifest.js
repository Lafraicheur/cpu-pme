globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d0abf855443c11a0.js",
    "static/chunks/1bc32688ff8c14aa.js",
    "static/chunks/fa5fce1a6b57434f.js",
    "static/chunks/9229ca47083d414d.js",
    "static/chunks/c938bf814795b97f.js",
    "static/chunks/turbopack-392d56124e74ee1d.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];