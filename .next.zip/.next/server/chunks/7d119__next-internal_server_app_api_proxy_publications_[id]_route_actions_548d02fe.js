module.exports=[60029,(e,o,d)=>{}];

//# sourceMappingURL=7d119__next-internal_server_app_api_proxy_publications_%5Bid%5D_route_actions_548d02fe.js.map