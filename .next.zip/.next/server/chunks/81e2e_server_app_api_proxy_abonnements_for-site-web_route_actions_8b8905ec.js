module.exports=[36237,(e,o,d)=>{}];

//# sourceMappingURL=81e2e_server_app_api_proxy_abonnements_for-site-web_route_actions_8b8905ec.js.map