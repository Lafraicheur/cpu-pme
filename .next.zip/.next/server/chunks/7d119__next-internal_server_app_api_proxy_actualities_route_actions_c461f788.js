module.exports=[69118,(e,o,d)=>{}];

//# sourceMappingURL=7d119__next-internal_server_app_api_proxy_actualities_route_actions_c461f788.js.map