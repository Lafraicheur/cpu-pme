module.exports=[2375,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_cpu-pme-site__next-internal_server_app__not-found_page_actions_419f7b35.js.map