module.exports=[37100,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_cpu-pme-site__next-internal_server_app_page_actions_c1c09941.js.map