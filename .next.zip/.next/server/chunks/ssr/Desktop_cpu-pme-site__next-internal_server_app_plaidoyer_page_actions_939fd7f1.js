module.exports=[38836,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_cpu-pme-site__next-internal_server_app_plaidoyer_page_actions_939fd7f1.js.map