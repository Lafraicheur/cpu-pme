module.exports=[32482,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_cpu-pme-site__next-internal_server_app_contact_page_actions_9b13d950.js.map