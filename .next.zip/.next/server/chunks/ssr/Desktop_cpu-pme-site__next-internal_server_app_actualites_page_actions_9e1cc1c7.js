module.exports=[95707,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_cpu-pme-site__next-internal_server_app_actualites_page_actions_9e1cc1c7.js.map