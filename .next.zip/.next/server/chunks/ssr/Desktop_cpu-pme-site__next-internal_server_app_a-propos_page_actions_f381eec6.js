module.exports=[57155,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_cpu-pme-site__next-internal_server_app_a-propos_page_actions_f381eec6.js.map