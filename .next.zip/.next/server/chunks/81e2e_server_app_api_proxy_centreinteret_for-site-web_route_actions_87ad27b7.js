module.exports=[68495,(e,o,d)=>{}];

//# sourceMappingURL=81e2e_server_app_api_proxy_centreinteret_for-site-web_route_actions_87ad27b7.js.map