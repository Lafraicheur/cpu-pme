module.exports=[89986,(e,o,d)=>{}];

//# sourceMappingURL=3d860_cpu-pme-site__next-internal_server_app_api_proxy_banners_route_actions_e7def796.js.map