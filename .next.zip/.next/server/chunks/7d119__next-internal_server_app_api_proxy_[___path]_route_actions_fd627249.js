module.exports=[69917,(e,o,d)=>{}];

//# sourceMappingURL=7d119__next-internal_server_app_api_proxy_%5B___path%5D_route_actions_fd627249.js.map