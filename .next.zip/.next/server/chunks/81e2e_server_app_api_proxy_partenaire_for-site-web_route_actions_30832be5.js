module.exports=[76647,(e,o,d)=>{}];

//# sourceMappingURL=81e2e_server_app_api_proxy_partenaire_for-site-web_route_actions_30832be5.js.map