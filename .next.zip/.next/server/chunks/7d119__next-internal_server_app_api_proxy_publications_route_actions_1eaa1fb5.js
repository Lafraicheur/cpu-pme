module.exports=[73901,(e,o,d)=>{}];

//# sourceMappingURL=7d119__next-internal_server_app_api_proxy_publications_route_actions_1eaa1fb5.js.map