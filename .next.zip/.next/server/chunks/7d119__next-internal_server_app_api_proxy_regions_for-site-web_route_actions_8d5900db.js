module.exports=[67476,(e,o,d)=>{}];

//# sourceMappingURL=7d119__next-internal_server_app_api_proxy_regions_for-site-web_route_actions_8d5900db.js.map