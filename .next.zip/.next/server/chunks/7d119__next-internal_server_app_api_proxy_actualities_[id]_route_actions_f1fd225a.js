module.exports=[70413,(e,o,d)=>{}];

//# sourceMappingURL=7d119__next-internal_server_app_api_proxy_actualities_%5Bid%5D_route_actions_f1fd225a.js.map