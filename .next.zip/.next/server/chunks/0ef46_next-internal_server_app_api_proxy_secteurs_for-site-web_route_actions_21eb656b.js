module.exports=[92841,(e,o,d)=>{}];

//# sourceMappingURL=0ef46_next-internal_server_app_api_proxy_secteurs_for-site-web_route_actions_21eb656b.js.map