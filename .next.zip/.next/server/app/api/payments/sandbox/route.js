var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/sandbox/route.js")
R.c("server/chunks/[root-of-the-server]__5e3b6de6._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/7d119__next-internal_server_app_api_payments_sandbox_route_actions_6da7ea9b.js")
R.m(69486)
module.exports=R.m(69486).exports
