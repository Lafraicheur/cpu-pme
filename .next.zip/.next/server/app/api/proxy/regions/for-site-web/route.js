var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/regions/for-site-web/route.js")
R.c("server/chunks/[root-of-the-server]__050b5990._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/7d119__next-internal_server_app_api_proxy_regions_for-site-web_route_actions_8d5900db.js")
R.m(30692)
module.exports=R.m(30692).exports
