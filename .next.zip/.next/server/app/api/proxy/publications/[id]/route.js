var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/publications/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__3074362d._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/7d119__next-internal_server_app_api_proxy_publications_[id]_route_actions_548d02fe.js")
R.m(51191)
module.exports=R.m(51191).exports
