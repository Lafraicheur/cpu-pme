var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/publications/route.js")
R.c("server/chunks/[root-of-the-server]__caa3a18f._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/7d119__next-internal_server_app_api_proxy_publications_route_actions_1eaa1fb5.js")
R.m(24859)
module.exports=R.m(24859).exports
