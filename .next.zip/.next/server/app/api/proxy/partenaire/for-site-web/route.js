var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/partenaire/for-site-web/route.js")
R.c("server/chunks/[root-of-the-server]__b2292983._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/81e2e_server_app_api_proxy_partenaire_for-site-web_route_actions_30832be5.js")
R.m(65207)
module.exports=R.m(65207).exports
