var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/centreinteret/for-site-web/route.js")
R.c("server/chunks/[root-of-the-server]__979470ca._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/81e2e_server_app_api_proxy_centreinteret_for-site-web_route_actions_87ad27b7.js")
R.m(53472)
module.exports=R.m(53472).exports
