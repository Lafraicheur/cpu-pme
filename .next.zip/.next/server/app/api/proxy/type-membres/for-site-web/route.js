var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/type-membres/for-site-web/route.js")
R.c("server/chunks/[root-of-the-server]__a49673a2._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/81e2e_server_app_api_proxy_type-membres_for-site-web_route_actions_faf96ab0.js")
R.m(69482)
module.exports=R.m(69482).exports
