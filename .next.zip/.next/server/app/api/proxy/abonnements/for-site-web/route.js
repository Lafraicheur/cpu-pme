var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/abonnements/for-site-web/route.js")
R.c("server/chunks/[root-of-the-server]__f7ec2ee3._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/81e2e_server_app_api_proxy_abonnements_for-site-web_route_actions_8b8905ec.js")
R.m(79906)
module.exports=R.m(79906).exports
