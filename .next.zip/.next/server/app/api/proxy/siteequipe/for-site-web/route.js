var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/siteequipe/for-site-web/route.js")
R.c("server/chunks/[root-of-the-server]__22ac4f99._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/81e2e_server_app_api_proxy_siteequipe_for-site-web_route_actions_5bab6749.js")
R.m(19016)
module.exports=R.m(19016).exports
