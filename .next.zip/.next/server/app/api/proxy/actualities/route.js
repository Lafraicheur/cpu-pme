var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/actualities/route.js")
R.c("server/chunks/[root-of-the-server]__e7b73dcd._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/7d119__next-internal_server_app_api_proxy_actualities_route_actions_c461f788.js")
R.m(78459)
module.exports=R.m(78459).exports
