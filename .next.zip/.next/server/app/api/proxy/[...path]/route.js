var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__9e06cbb3._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/7d119__next-internal_server_app_api_proxy_[___path]_route_actions_fd627249.js")
R.m(64851)
module.exports=R.m(64851).exports
