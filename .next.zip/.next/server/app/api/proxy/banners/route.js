var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/banners/route.js")
R.c("server/chunks/[root-of-the-server]__56d767e1._.js")
R.c("server/chunks/[root-of-the-server]__52baaebc._.js")
R.c("server/chunks/70f1c_next_03dca6ac._.js")
R.c("server/chunks/3d860_cpu-pme-site__next-internal_server_app_api_proxy_banners_route_actions_e7def796.js")
R.m(30442)
module.exports=R.m(30442).exports
